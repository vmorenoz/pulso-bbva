# Investigación · {{work-id}} · {{pregunta}}
<!-- template: research@1.0 -->
Guía para documento solicitado; omitir alternativas/tablas sin decisión real. El retorno en conversación usa las tres secciones de result.md.
## Necesidad e incertidumbre
{{Qué decisión permite tomar este encargo.}}
## Hallazgos y fuentes
| Hallazgo | Tipo: hecho/hipótesis | Fuente verificable | Fecha/versión |
|---|---|---|---|
| {{hallazgo}} | {{tipo}} | {{archivo o documentación}} | {{vigencia}} |
## Alternativas y consecuencias
{{Opciones reales, coste, restricciones, reversibilidad y recomendación razonada.}}
## Preguntas para el usuario, vía Pulso
{{Solo decisiones humanas necesarias; investigar antes imports, API, configuración y términos
del dominio. Un workaround no demuestra reparación de la causa.}}
## Confirmaciones recibidas
{{Lo que el usuario ya respondió; no volver a preguntarlo.}}
## Conclusión y límites
{{Qué está listo para especificar/planificar y qué sigue bloqueado.}}
