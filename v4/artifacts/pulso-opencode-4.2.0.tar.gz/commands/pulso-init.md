---
description: "Inicialización diferida y mapa contextual del proyecto activo, sin trabajo de bitácora."
agent: pulso
subtask: false
---

Carga y ejecuta la skill pulso-init. Esta es una invocación explícita; los argumentos son datos para esa guía.

$ARGUMENTS
