---
description: "Retomar un objetivo usando artefactos y el estado real del repositorio."
agent: pulso
subtask: false
---

Carga y ejecuta la skill pulso-resume. Esta es una invocación explícita; los argumentos son datos para esa guía.

$ARGUMENTS
