---
description: "Consultar el índice de trabajos del proyecto activo sin recorrerlos todos."
agent: pulso
subtask: false
---

Carga y ejecuta la skill pulso-status. Esta es una invocación explícita; los argumentos son datos para esa guía.

$ARGUMENTS
