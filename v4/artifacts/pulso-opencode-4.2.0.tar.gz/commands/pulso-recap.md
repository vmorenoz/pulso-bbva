---
description: "Resumir cierres de un período y el snapshot actual de trabajos abiertos."
agent: pulso
subtask: false
---

Carga y ejecuta la skill pulso-recap. Esta es una invocación explícita; los argumentos son datos para esa guía.

$ARGUMENTS
